package com.patac.hmi.grpcbinderservice;

import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleService;

import com.example.grpcbinderdemo.BodyAccessGrpc;
import com.example.grpcbinderdemo.State;
import com.example.grpcbinderdemo.UpdateWindowRequest;
import com.example.grpcbinderdemo.Window;
import com.example.grpcbinderdemo.WindowOptions;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import io.grpc.ManagedChannel;
import io.grpc.Server;
import io.grpc.Status;
import io.grpc.binder.AndroidComponentAddress;
import io.grpc.binder.BinderChannelBuilder;
import io.grpc.binder.BinderServerBuilder;
import io.grpc.binder.IBinderReceiver;
import io.grpc.binder.SecurityPolicies;
import io.grpc.binder.SecurityPolicy;
import io.grpc.binder.ServerSecurityPolicy;
import io.grpc.binder.UntrustedSecurityPolicies;
import io.grpc.stub.StreamObserver;

public class GrpcBindService extends LifecycleService {

    private static final String TAG = "GrpcBindService";

    @Nullable
    private Server mServer;
    private IBinderReceiver receiver;

    @Override
    public void onCreate() {
        super.onCreate();
        //安全策略
        ServerSecurityPolicy securityPolicy = ServerSecurityPolicy.newBuilder()
                .servicePolicy("grpcdemo.BodyAccess", UntrustedSecurityPolicies.untrustedPublic())
                .build();

        AndroidComponentAddress address = AndroidComponentAddress
                .forRemoteComponent(getPackageName(), getClass().getName());
        receiver = new IBinderReceiver();
        mServer = BinderServerBuilder.forAddress(address, receiver)
                .securityPolicy(securityPolicy)
                .addService(new WindowServiceImpl())
                .build();
        try {
            mServer.start();
        } catch (IOException ioe) {
            Log.w(TAG, "IOException: " + ioe.getMessage());
        }
    }

    @Override
    public IBinder onBind(@NonNull Intent intent) {
        Log.d(TAG, "onBind: ");
        super.onBind(intent);
        return receiver.get();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "GrpcBindService Destroy");
        if (mServer != null) {
            mServer.shutdown();
            mServer = null;
        }
        super.onDestroy();
    }

    class WindowServiceImpl extends BodyAccessGrpc.BodyAccessImplBase {

        @Override
        public void updateWindow(UpdateWindowRequest request, StreamObserver<State> responseObserver) {
            Window window = request.getWindow();
            Log.d(TAG, "WindowServiceImpl updateWindow: " + window.getPosition());
            State state = State.newBuilder().setCode(0).build();
            responseObserver.onNext(state);
            responseObserver.onCompleted();
        }

        @Override
        public void subWindow(WindowOptions request, StreamObserver<Window> responseObserver) {
            Log.d(TAG, "subWindow: " + request.getResourceName());
            for (int i = 0; i < 100; i++) {
                Window window = Window.newBuilder().setPosition(i).build();
                responseObserver.onNext(window);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            responseObserver.onCompleted();

        }
    }
}
