package com.patac.hmi.grpcbinderclient;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.grpc.ManagedChannel;
import io.grpc.binder.AndroidComponentAddress;
import io.grpc.binder.BinderChannelBuilder;
import io.grpc.binder.UntrustedSecurityPolicies;

public class MainActivity extends AppCompatActivity {

    Button connect, sub, update;
    private WindowClient mClient;
    private ExecutorService cacheThreadPoll = Executors.newCachedThreadPool();
    private final static String PACKAGE = "com.patac.hmi.grpcbinderservice";
    private final static String CLASS_NAME = "com.patac.hmi.grpcbinderservice.GrpcBindService";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connect = findViewById(R.id.connect);
        sub = findViewById(R.id.sub);
        update = findViewById(R.id.update);
        initListener();
    }

    private void initListener() {
        connect.setOnClickListener(view -> {
            AndroidComponentAddress address = AndroidComponentAddress
                    .forRemoteComponent(PACKAGE, CLASS_NAME);
            ManagedChannel mChannel = BinderChannelBuilder
                    .forAddress(address, getApplicationContext())
                    .securityPolicy(UntrustedSecurityPolicies.untrustedPublic())
                    .build();
            mClient = new WindowClient(mChannel);
            connect.setEnabled(false);
        });

        update.setOnClickListener(view -> {
            cacheThreadPoll.execute(() -> {
                int num = (int) (Math.random() * 100);
                mClient.updateWindow(num);
            });
        });

        sub.setOnClickListener(view -> {
            cacheThreadPoll.execute(() -> {
                mClient.subWindow();
            });
        });
    }
}