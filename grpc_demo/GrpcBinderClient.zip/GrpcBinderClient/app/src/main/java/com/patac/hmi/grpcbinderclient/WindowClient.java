package com.patac.hmi.grpcbinderclient;

import android.util.Log;

import com.example.grpcbinderdemo.BodyAccessGrpc;
import com.example.grpcbinderdemo.State;
import com.example.grpcbinderdemo.UpdateWindowRequest;
import com.example.grpcbinderdemo.Window;
import com.example.grpcbinderdemo.WindowOptions;
import com.example.grpcbinderdemo.Window_Resources;

import java.util.Iterator;

import io.grpc.Channel;
import io.grpc.StatusRuntimeException;

/**
 * @Description: Client
 * @Author: hechunhui
 * @CreateDate: 2022/11/24 16:00
 * @Version: 1.0
 */
public class WindowClient {
    private static final String TAG = "GrpcBind-WindowClient-hch";

    private final BodyAccessGrpc.BodyAccessBlockingStub blockingStub;

    public WindowClient(Channel channel) {
        blockingStub = BodyAccessGrpc.newBlockingStub(channel);
    }

    public void updateWindow(int position) {
        Log.i(TAG, "updateWindow: " + blockingStub.getClass().getName());
        Window window = Window.newBuilder().setPosition(position).build();
        UpdateWindowRequest request = UpdateWindowRequest.newBuilder().setWindow(window).build();
        State state;
        try {
            state = blockingStub.updateWindow(request);
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            return;
        }
        Log.d(TAG, "updateWindow: response :" + state.getCode());
    }

    public void subWindow() {
        WindowOptions windowOptions = WindowOptions.newBuilder().setResourceName(Window_Resources.front_left).build();
        Iterator<Window> windowIterable;
        try {
            windowIterable = blockingStub.subWindow(windowOptions);
            while (windowIterable.hasNext()) {
                Window window = windowIterable.next();
                Log.d(TAG, "SubWindow: response " + window.getPosition());
            }
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
        }
    }

}
